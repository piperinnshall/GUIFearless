package com.piperinnshall.fluentguijava.demo;

import com.piperinnshall.fluentguijava.core.FluentGUI;
import com.piperinnshall.fluentguijava.fearless.PanelBuilder.Flow;
import com.piperinnshall.fluentguijava.fearless.Slot;
import com.piperinnshall.fluentguijava.fearless.Scope;
import com.piperinnshall.fluentguijava.fearless.Types.*;
import java.util.function.Consumer;

public class LayeredDemo {
  public static void main() {
    Scope<Flow> flow2 = f -> f
      .background(new Color(new Red(120), new Green(150), new Blue(30)))
      .size(new Dimension(new Width(250), new Height(250)))
      .button("Boom", () -> { throw new RuntimeException("Boom"); }, Slot.of())
      .button("Crash", () -> { throw new RuntimeException("Crash"); }, Slot.of())
      // .onMouse(mouse -> mouse
      //   .clicked(click -> 
      //       System.out.println(click.mousePosition())
      //     )
      //   )
    ;

    Scope<Flow> flow1 = f -> f
      .background(new Color(new Red(30), new Green(30), new Blue(30)))
      .size(new Dimension(new Width(500), new Height(500)))
      .label("Layered Mouse Handling", Slot.of())
      .flow(flow2)
      .label("Layered Mouse Handling", Slot.of())
      // .onMouse(mouse -> mouse
      //   .clicked(click -> 
      //       System.out.println(click.mousePosition())
      //     )
      //   )
    ;
    var result = new FluentGUI().run(gui -> gui.flow(flow1));

    System.out.println(switch(result) {
      case FluentGUIResult.Unknown() -> "Unknown";
      case FluentGUIResult.Closed() -> "Closed";
      case FluentGUIResult.Crashed(RuntimeException cause) -> "Crashed with error: " + cause.getLocalizedMessage();
      });
    }
  }
